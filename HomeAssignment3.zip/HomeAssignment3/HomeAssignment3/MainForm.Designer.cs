﻿namespace HomeAssignment3
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.labelFavArtist = new System.Windows.Forms.Label();
            this.textBox_Artist = new System.Windows.Forms.TextBox();
            this.checkBox_Agreement = new System.Windows.Forms.CheckBox();
            this.button_Submit = new System.Windows.Forms.Button();
            this.button_NextForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(31, 27);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(38, 13);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "Name:";
            // 
            // textBox_Name
            // 
            this.textBox_Name.Location = new System.Drawing.Point(111, 24);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(148, 20);
            this.textBox_Name.TabIndex = 1;
            // 
            // labelFavArtist
            // 
            this.labelFavArtist.AutoSize = true;
            this.labelFavArtist.Location = new System.Drawing.Point(31, 56);
            this.labelFavArtist.Name = "labelFavArtist";
            this.labelFavArtist.Size = new System.Drawing.Size(74, 13);
            this.labelFavArtist.TabIndex = 2;
            this.labelFavArtist.Text = "Favorite Artist:";
            // 
            // textBox_Artist
            // 
            this.textBox_Artist.Location = new System.Drawing.Point(111, 53);
            this.textBox_Artist.Name = "textBox_Artist";
            this.textBox_Artist.Size = new System.Drawing.Size(148, 20);
            this.textBox_Artist.TabIndex = 3;
            // 
            // checkBox_Agreement
            // 
            this.checkBox_Agreement.AutoSize = true;
            this.checkBox_Agreement.Location = new System.Drawing.Point(111, 92);
            this.checkBox_Agreement.Name = "checkBox_Agreement";
            this.checkBox_Agreement.Size = new System.Drawing.Size(197, 17);
            this.checkBox_Agreement.TabIndex = 4;
            this.checkBox_Agreement.Text = "All of the content I put above is true!";
            this.checkBox_Agreement.UseVisualStyleBackColor = true;
            // 
            // button_Submit
            // 
            this.button_Submit.Location = new System.Drawing.Point(111, 153);
            this.button_Submit.Name = "button_Submit";
            this.button_Submit.Size = new System.Drawing.Size(75, 23);
            this.button_Submit.TabIndex = 5;
            this.button_Submit.Text = "Submit";
            this.button_Submit.UseVisualStyleBackColor = true;
            this.button_Submit.Click += new System.EventHandler(this.button_Submit_Click);
            // 
            // button_NextForm
            // 
            this.button_NextForm.Location = new System.Drawing.Point(111, 124);
            this.button_NextForm.Name = "button_NextForm";
            this.button_NextForm.Size = new System.Drawing.Size(104, 23);
            this.button_NextForm.TabIndex = 6;
            this.button_NextForm.Text = "Open Next Form";
            this.button_NextForm.UseVisualStyleBackColor = true;
            this.button_NextForm.Click += new System.EventHandler(this.button_NextForm_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_NextForm);
            this.Controls.Add(this.button_Submit);
            this.Controls.Add(this.checkBox_Agreement);
            this.Controls.Add(this.textBox_Artist);
            this.Controls.Add(this.labelFavArtist);
            this.Controls.Add(this.textBox_Name);
            this.Controls.Add(this.labelName);
            this.Name = "MainForm";
            this.Text = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.Label labelFavArtist;
        private System.Windows.Forms.TextBox textBox_Artist;
        private System.Windows.Forms.CheckBox checkBox_Agreement;
        private System.Windows.Forms.Button button_Submit;
        private System.Windows.Forms.Button button_NextForm;
    }
}

