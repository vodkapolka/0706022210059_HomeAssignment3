﻿namespace HomeAssignment3
{
    partial class SecondForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_FavColorBG = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton_Green = new System.Windows.Forms.RadioButton();
            this.radioButton_Violet = new System.Windows.Forms.RadioButton();
            this.radioButton_Red = new System.Windows.Forms.RadioButton();
            this.radioButton_Gray = new System.Windows.Forms.RadioButton();
            this.radioButton_Blue = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton_Blue2 = new System.Windows.Forms.RadioButton();
            this.radioButton_Red2 = new System.Windows.Forms.RadioButton();
            this.radioButton_Green2 = new System.Windows.Forms.RadioButton();
            this.label_FavColorText = new System.Windows.Forms.Label();
            this.checkBox_Agreement = new System.Windows.Forms.CheckBox();
            this.checkBox_Agreement2 = new System.Windows.Forms.CheckBox();
            this.button_MAGIC = new System.Windows.Forms.Button();
            this.label_ShowIntro = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_FavColorBG
            // 
            this.label_FavColorBG.AutoSize = true;
            this.label_FavColorBG.Location = new System.Drawing.Point(3, 9);
            this.label_FavColorBG.Name = "label_FavColorBG";
            this.label_FavColorBG.Size = new System.Drawing.Size(178, 13);
            this.label_FavColorBG.TabIndex = 0;
            this.label_FavColorBG.Text = "Pick your favorite background color:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton_Green);
            this.panel1.Controls.Add(this.label_FavColorBG);
            this.panel1.Controls.Add(this.radioButton_Violet);
            this.panel1.Controls.Add(this.radioButton_Red);
            this.panel1.Controls.Add(this.radioButton_Gray);
            this.panel1.Controls.Add(this.radioButton_Blue);
            this.panel1.Location = new System.Drawing.Point(26, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(273, 98);
            this.panel1.TabIndex = 1;
            // 
            // radioButton_Green
            // 
            this.radioButton_Green.AutoSize = true;
            this.radioButton_Green.Location = new System.Drawing.Point(148, 48);
            this.radioButton_Green.Name = "radioButton_Green";
            this.radioButton_Green.Size = new System.Drawing.Size(54, 17);
            this.radioButton_Green.TabIndex = 6;
            this.radioButton_Green.TabStop = true;
            this.radioButton_Green.Text = "Green";
            this.radioButton_Green.UseVisualStyleBackColor = true;
            // 
            // radioButton_Violet
            // 
            this.radioButton_Violet.AutoSize = true;
            this.radioButton_Violet.Location = new System.Drawing.Point(148, 25);
            this.radioButton_Violet.Name = "radioButton_Violet";
            this.radioButton_Violet.Size = new System.Drawing.Size(51, 17);
            this.radioButton_Violet.TabIndex = 5;
            this.radioButton_Violet.TabStop = true;
            this.radioButton_Violet.Text = "Violet";
            this.radioButton_Violet.UseVisualStyleBackColor = true;
            // 
            // radioButton_Red
            // 
            this.radioButton_Red.AutoSize = true;
            this.radioButton_Red.Location = new System.Drawing.Point(6, 25);
            this.radioButton_Red.Name = "radioButton_Red";
            this.radioButton_Red.Size = new System.Drawing.Size(45, 17);
            this.radioButton_Red.TabIndex = 2;
            this.radioButton_Red.TabStop = true;
            this.radioButton_Red.Text = "Red";
            this.radioButton_Red.UseVisualStyleBackColor = true;
            // 
            // radioButton_Gray
            // 
            this.radioButton_Gray.AutoSize = true;
            this.radioButton_Gray.Location = new System.Drawing.Point(6, 71);
            this.radioButton_Gray.Name = "radioButton_Gray";
            this.radioButton_Gray.Size = new System.Drawing.Size(47, 17);
            this.radioButton_Gray.TabIndex = 4;
            this.radioButton_Gray.TabStop = true;
            this.radioButton_Gray.Text = "Gray";
            this.radioButton_Gray.UseVisualStyleBackColor = true;
            // 
            // radioButton_Blue
            // 
            this.radioButton_Blue.AutoSize = true;
            this.radioButton_Blue.Location = new System.Drawing.Point(6, 48);
            this.radioButton_Blue.Name = "radioButton_Blue";
            this.radioButton_Blue.Size = new System.Drawing.Size(46, 17);
            this.radioButton_Blue.TabIndex = 3;
            this.radioButton_Blue.TabStop = true;
            this.radioButton_Blue.Text = "Blue";
            this.radioButton_Blue.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton_Blue2);
            this.panel2.Controls.Add(this.radioButton_Red2);
            this.panel2.Controls.Add(this.radioButton_Green2);
            this.panel2.Controls.Add(this.label_FavColorText);
            this.panel2.Location = new System.Drawing.Point(26, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(273, 98);
            this.panel2.TabIndex = 2;
            // 
            // radioButton_Blue2
            // 
            this.radioButton_Blue2.AutoSize = true;
            this.radioButton_Blue2.Location = new System.Drawing.Point(6, 25);
            this.radioButton_Blue2.Name = "radioButton_Blue2";
            this.radioButton_Blue2.Size = new System.Drawing.Size(46, 17);
            this.radioButton_Blue2.TabIndex = 7;
            this.radioButton_Blue2.TabStop = true;
            this.radioButton_Blue2.Text = "Blue";
            this.radioButton_Blue2.UseVisualStyleBackColor = true;
            // 
            // radioButton_Red2
            // 
            this.radioButton_Red2.AutoSize = true;
            this.radioButton_Red2.Location = new System.Drawing.Point(6, 48);
            this.radioButton_Red2.Name = "radioButton_Red2";
            this.radioButton_Red2.Size = new System.Drawing.Size(45, 17);
            this.radioButton_Red2.TabIndex = 8;
            this.radioButton_Red2.TabStop = true;
            this.radioButton_Red2.Text = "Red";
            this.radioButton_Red2.UseVisualStyleBackColor = true;
            // 
            // radioButton_Green2
            // 
            this.radioButton_Green2.AutoSize = true;
            this.radioButton_Green2.Location = new System.Drawing.Point(6, 71);
            this.radioButton_Green2.Name = "radioButton_Green2";
            this.radioButton_Green2.Size = new System.Drawing.Size(54, 17);
            this.radioButton_Green2.TabIndex = 9;
            this.radioButton_Green2.TabStop = true;
            this.radioButton_Green2.Text = "Green";
            this.radioButton_Green2.UseVisualStyleBackColor = true;
            // 
            // label_FavColorText
            // 
            this.label_FavColorText.AutoSize = true;
            this.label_FavColorText.Location = new System.Drawing.Point(3, 9);
            this.label_FavColorText.Name = "label_FavColorText";
            this.label_FavColorText.Size = new System.Drawing.Size(138, 13);
            this.label_FavColorText.TabIndex = 7;
            this.label_FavColorText.Text = "Pick your favorite text color:";
            // 
            // checkBox_Agreement
            // 
            this.checkBox_Agreement.AutoSize = true;
            this.checkBox_Agreement.Location = new System.Drawing.Point(26, 235);
            this.checkBox_Agreement.Name = "checkBox_Agreement";
            this.checkBox_Agreement.Size = new System.Drawing.Size(187, 17);
            this.checkBox_Agreement.TabIndex = 3;
            this.checkBox_Agreement.Text = "I agree to the Terms of Agreement";
            this.checkBox_Agreement.UseVisualStyleBackColor = true;
            this.checkBox_Agreement.CheckedChanged += new System.EventHandler(this.checkBox_Agreement_CheckedChanged);
            // 
            // checkBox_Agreement2
            // 
            this.checkBox_Agreement2.AutoSize = true;
            this.checkBox_Agreement2.Location = new System.Drawing.Point(26, 258);
            this.checkBox_Agreement2.Name = "checkBox_Agreement2";
            this.checkBox_Agreement2.Size = new System.Drawing.Size(196, 17);
            this.checkBox_Agreement2.TabIndex = 4;
            this.checkBox_Agreement2.Text = "All the choices I pick above are true";
            this.checkBox_Agreement2.UseVisualStyleBackColor = true;
            this.checkBox_Agreement2.CheckedChanged += new System.EventHandler(this.checkBox_Agreement2_CheckedChanged);
            // 
            // button_MAGIC
            // 
            this.button_MAGIC.Location = new System.Drawing.Point(26, 281);
            this.button_MAGIC.Name = "button_MAGIC";
            this.button_MAGIC.Size = new System.Drawing.Size(75, 23);
            this.button_MAGIC.TabIndex = 5;
            this.button_MAGIC.Text = "Magic";
            this.button_MAGIC.UseVisualStyleBackColor = true;
            this.button_MAGIC.Click += new System.EventHandler(this.button_MAGIC_Click);
            // 
            // label_ShowIntro
            // 
            this.label_ShowIntro.AutoSize = true;
            this.label_ShowIntro.Location = new System.Drawing.Point(23, 325);
            this.label_ShowIntro.Name = "label_ShowIntro";
            this.label_ShowIntro.Size = new System.Drawing.Size(16, 13);
            this.label_ShowIntro.TabIndex = 6;
            this.label_ShowIntro.Text = "...";
            // 
            // SecondForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_ShowIntro);
            this.Controls.Add(this.button_MAGIC);
            this.Controls.Add(this.checkBox_Agreement2);
            this.Controls.Add(this.checkBox_Agreement);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "SecondForm";
            this.Text = "Main";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_FavColorBG;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton_Green;
        private System.Windows.Forms.RadioButton radioButton_Violet;
        private System.Windows.Forms.RadioButton radioButton_Red;
        private System.Windows.Forms.RadioButton radioButton_Gray;
        private System.Windows.Forms.RadioButton radioButton_Blue;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton_Blue2;
        private System.Windows.Forms.RadioButton radioButton_Red2;
        private System.Windows.Forms.RadioButton radioButton_Green2;
        private System.Windows.Forms.Label label_FavColorText;
        private System.Windows.Forms.CheckBox checkBox_Agreement;
        private System.Windows.Forms.CheckBox checkBox_Agreement2;
        private System.Windows.Forms.Button button_MAGIC;
        private System.Windows.Forms.Label label_ShowIntro;
    }
}