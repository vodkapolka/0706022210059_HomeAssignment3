﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeAssignment3
{
    public partial class MainForm : Form
    {
        public MainForm instance;
        public TextBox textBox_Color;
        bool submit = false;
        bool nextform = false;
        
        SecondForm secondForm = new SecondForm();
        public MainForm()
        {
            InitializeComponent();
            instance = this;

            if (submit == false)
            {
                button_Submit.Enabled = false;
            }
        }

        private void button_NextForm_Click(object sender, EventArgs e)
        {
            nextform = true;

            if (checkBox_Agreement.Checked && nextform == true)
            {
                button_Submit.Enabled = true;
            }

            secondForm.Show();

        }

        private void button_Submit_Click(object sender, EventArgs e)
        {
            if (textBox_Name.Text == "" || textBox_Artist.Text == "")
            {
                MessageBox.Show("Please type your name and your favorite artist inside the textboxes.");
            }
            else
            {
                secondForm.instance.label_AfterSubmit.Text = "Hi, my name is " + textBox_Name.Text + ". My favorite artist is " + textBox_Artist.Text + ".";
            } 
        }
    }
}
