﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace HomeAssignment3
{
    public partial class SecondForm : Form
    {
        public SecondForm instance;
        public Label label_AfterSubmit;
        public SecondForm()
        {
            InitializeComponent();
            instance = this;
            label_AfterSubmit = label_ShowIntro;

            button_MAGIC.Enabled = false;
            

        }

        private void button_MAGIC_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (radioButton_Blue.Checked == false && radioButton_Gray.Checked == false && radioButton_Green.Checked == false && radioButton_Red.Checked == false && radioButton_Violet.Checked == false)
            {
                count++;
            }

            if (radioButton_Blue2.Checked == false && radioButton_Green2.Checked == false && radioButton_Red2.Checked == false)
            {
                count++;
            }

            if (count != 0)
            {
                MessageBox.Show("You need to choose at least 1 of each radio buttons that has been shown.");
            }
            else
            {
                MainForm Form1 = new MainForm();
                if (checkBox_Agreement.Checked && checkBox_Agreement2.Checked)
                {
                    if (radioButton_Red.Checked)
                    {
                        Form1.BackColor = Color.Red;
                    }
                    else if (radioButton_Blue.Checked)
                    {
                        Form1.BackColor = Color.Blue;
                    }
                    else if (radioButton_Gray.Checked)
                    {
                        Form1.BackColor = Color.Gray;
                    }
                    else if (radioButton_Violet.Checked)
                    {
                        Form1.BackColor = Color.Violet;
                    }
                    else if (radioButton_Green.Checked)
                    {
                        Form1.BackColor = Color.Green;
                    }
                    if (radioButton_Blue2.Checked)
                    {
                        Form1.ForeColor = Color.AliceBlue;
                    }
                    else if (radioButton_Red2.Checked)
                    {
                        Form1.ForeColor = Color.IndianRed;
                    }
                    else if (radioButton_Green2.Checked)
                    {
                        Form1.ForeColor = Color.Green;
                    }



                }
                Form1.Show();
            }
        }

        private void checkBox_Agreement_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_Agreement.Checked == true && checkBox_Agreement2.Checked == true)
            {
                button_MAGIC.Enabled = true;
            }
        }

        private void checkBox_Agreement2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_Agreement.Checked == true && checkBox_Agreement2.Checked == true)
            {
                button_MAGIC.Enabled = true;
            }
        }
    }
}
